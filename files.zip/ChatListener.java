package dev.nickbypass;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.essentialsx.api.v2.services.essentials.IEssentials;
import net.essentialsx.api.v2.services.essentials.IUser;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

public class ChatListener implements Listener {

    private final NickBypass plugin;
    private IEssentials essentials;

    public ChatListener(NickBypass plugin) {
        this.plugin = plugin;
    }

    private IEssentials getEssentials() {
        if (essentials == null) {
            var ess = Bukkit.getPluginManager().getPlugin("Essentials");
            if (ess instanceof IEssentials api) {
                essentials = api;
            }
        }
        return essentials;
    }

    // MONITOR priority so we see the final formatted message from LuckPerms chat
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        Player sender = event.getPlayer();

        // Check if the sender has a nickname set
        String nickname = getNickname(sender);
        if (nickname == null || nickname.equals(sender.getName())) return; // no nick, nothing to do

        // For each viewer who is bypassing, replace the nickname with the real username
        event.viewers().forEach(audience -> {
            if (!(audience instanceof Player viewer)) return;
            if (!plugin.isBypassing(viewer)) return;

            // Replace nickname text in the rendered message with the real username
            Component original = event.renderer().render(sender, event.getPlayer().displayName(), event.message(), viewer);
            Component replaced = replaceNickWithUsername(original, nickname, sender.getName());

            // Override what this specific viewer sees by using the viewer-specific render
            // We achieve this by removing the viewer and re-adding with a custom renderer
            event.viewers().remove(viewer);
            viewer.sendMessage(replaced);
        });
    }

    /**
     * Gets the EssentialsX nickname of a player, stripped of color codes, or null if none.
     */
    private String getNickname(Player player) {
        IEssentials ess = getEssentials();
        if (ess == null) return null;

        IUser user = ess.getUser(player);
        if (user == null) return null;

        String nick = user.getNickname();
        if (nick == null || nick.isBlank()) return null;

        // Strip color/formatting codes for matching purposes
        return net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
                .legacyAmpersand()
                .deserialize(nick)
                .let(c -> PlainTextComponentSerializer.plainText().serialize(c));
    }

    /**
     * Walks the component tree and replaces any occurrence of the nickname text
     * with the real username, preserving surrounding formatting.
     */
    private Component replaceNickWithUsername(Component component, String nickname, String realName) {
        return component.replaceText(
                TextReplacementConfig.builder()
                        .matchLiteral(nickname)
                        .replacement(Component.text(realName))
                        .build()
        );
    }
}
